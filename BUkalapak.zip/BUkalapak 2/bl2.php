<?php
error_reporting(0);
require_once __DIR__ . "/vendor/autoload.php";
use InitPHP\CLITable\Table;
use Povils\Figlet\Figlet;
date_default_timezone_set("Asia/Jakarta");
$table = new Table();
$figlet = new Figlet();

$table->setBorderStyle(Table::COLOR_WHITE);
$table->setCellStyle(Table::COLOR_WHITE);
$table->setHeaderStyle(Table::COLOR_GREEN, Table::BOLD);
echo "Waiting For Read File cookie.txt\n\n";
$cookiezku = file_get_contents("cookie.txt");
$cookiezku = trim($cookiezku);
$xsrf = get_between($cookiezku, ' XSRF-TOKEN=', ';');
while (true) {
    $randAngka = acakc(13);
    $headers = [
        "Host: seller.bukalapak.com",
        "Cookie: " . $cookiezku . "",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: application/json, text/plain, */*",
        "Accept-Language: id,en-US;q=0.7,en;q=0.3",
        "Content-Type: application/json;charset=utf-8",
        "X-Xsrf-Token: " . $xsrf . "",
        "Origin: https://seller.bukalapak.com",
        "Referer: https://seller.bukalapak.com/transactions?context=sale&limit=30&offset=0&tab=dikirim&sort=-paid_at",
        "Sec-Fetch-Dest: empty",
        "Sec-Fetch-Mode: cors",
        "Sec-Fetch-Site: same-origin",
        "Te: trailers",
    ];

    $data = '{"application_id":1,"authenticity_token":""}';
    $getToken = curl(
        "https://seller.bukalapak.com/api/authenticate",
        $data,
        $headers
    );
    $getToken = json_decode($getToken[1]);
    $token = $getToken->access_token;

    if ($token) {
        echo date("[H:i:s]") .
        " \e[0;32mSuccessully Login $token !!! Check u cookie.txt\e[0m\n";

    } else {
        echo date("[H:i:s]") .
        " \e[0;31mFailure Login $token !!! Check u cookie.txt\e[0m\n";
    }
    $headers = [
        "HTTP/2",
        "Host: api.bukalapak.com",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
        "Accept: application/json",
        "Accept-Language: id,en-US;q=0.7,en;q=0.3",
        "Content-Type: application/json",
        "Origin: https://seller.bukalapak.com",
        "Referer: https://seller.bukalapak.com/",
        "Sec-Fetch-Dest: empty",
        "Sec-Fetch-Mode: cors",
        "Sec-Fetch-Site: same-site",
        "Te: trailers",
    ];

    $data =
        '{"aggregate":{"dibayar":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=non_cancel_requested"},"dibatalkan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=cancel_requested"},"diproses":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=accepted"},"dikirim":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=received&states[]=delivered"},"selesai":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=remitted"},"dikembalikan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=refunded"}}}';
    $checkOrder = curl(
        "https://api.bukalapak.com/aggregate?access_token=" . $token . "",
        $data,
        $headers
    );
    $checkOrder = json_decode($checkOrder[1]);
    $total = $checkOrder->data->dibayar;
    $totalKuh = count($total);

    $time = date("Y-m-d");

    if (file_exists("$time.csv")) {
        echo "! File Exist $time.csv\n\n";
    } else {
        $list = [
            [
                "No Order",
                "ID Higgs",
                "Name Product",
                "Qty",
                "Price",
                "Note",
                "Status Chip",
                "Time Order",
            ],
            ["", "", "", "", "", "", "", ""],
        ];

        $fp = fopen("$time.csv", "a+");

        foreach ($list as $date) {
            fputcsv($fp, $date);
        }
    }

    if ($totalKuh) {
        for ($indexLur = 0; $indexLur < $totalKuh; $indexLur++) {
            $headers = [
                "Host: seller.bukalapak.com",
                "Cookie: " . $cookiezku . "",
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
                "Accept: application/json, text/plain, */*",
                "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                "Content-Type: application/json;charset=utf-8",
                "X-Xsrf-Token: " . $xsrf . "",
                "Origin: https://seller.bukalapak.com",
                "Referer: https://seller.bukalapak.com/transactions?context=sale&limit=30&offset=0&tab=dikirim&sort=-paid_at",
                "Sec-Fetch-Dest: empty",
                "Sec-Fetch-Mode: cors",
                "Sec-Fetch-Site: same-origin",
                "Te: trailers",
            ];

            $data = '{"application_id":1,"authenticity_token":""}';
            $getToken = curl(
                "https://seller.bukalapak.com/api/authenticate",
                $data,
                $headers
            );
            $getToken = json_decode($getToken[1]);
            $token = $getToken->access_token;
            $headers = [
                "Host: api.bukalapak.com",
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
                "Accept: application/json",
                "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                "Content-Type: application/json",
                "Origin: https://seller.bukalapak.com",
                "Referer: https://seller.bukalapak.com/",
                "Sec-Fetch-Dest: empty",
                "Sec-Fetch-Mode: cors",
                "Sec-Fetch-Site: same-site",
                "Te: trailers",
            ];

            $data =
                '{"aggregate":{"dibayar":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=non_cancel_requested"},"dibatalkan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=cancel_requested"},"diproses":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=accepted"},"dikirim":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=received&states[]=delivered"},"selesai":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=remitted"},"dikembalikan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=refunded"}}}';
            $checkOrder = curl(
                "https://api.bukalapak.com/aggregate?access_token=" .
                    $token .
                    "",
                $data,
                $headers
            );
            $checkOrder = json_decode($checkOrder[1]);

            if ($checkOrder->data->dibayar[$indexLur]) {
                $idOrder = $checkOrder->data->dibayar[$indexLur]->id;
                $idOrderMu =
                    $checkOrder->data->dibayar[$indexLur]->transaction_id;
                $productName =
                    $checkOrder->data->dibayar[$indexLur]->items[0]->product
                        ->name;
                $quantity =
                    $checkOrder->data->dibayar[$indexLur]->items[0]->quantity;
                $price =
                    $checkOrder->data->dibayar[$indexLur]->items[0]->product
                        ->price;
                $gameId =
                    $checkOrder->data->dibayar[$indexLur]->options->buyer_note;

                $headers = [
                    "HTTP/2",
                    "Host: api.bukalapak.com",
                    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
                    "Accept: application/json",
                    "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                    "Content-Type: application/json",
                    "Origin: https://seller.bukalapak.com",
                    "Referer: https://seller.bukalapak.com/",
                    "Sec-Fetch-Dest: empty",
                    "Sec-Fetch-Mode: cors",
                    "Sec-Fetch-Site: same-site",
                    "Te: trailers",
                ];

                $data =
                    '{"aggregate":{"' .
                    $idOrder .
                    '":{"method":"PUT","path":"/transactions/' .
                    $idOrder .
                    '/status","body":{"state":"accepted"},"timeout":240000}}}';
                $accept = curl(
                    "https://api.bukalapak.com/aggregate?access_token=" .
                        $token .
                        "",
                    $data,
                    $headers
                );
            }

            $headers = [
                "Host: api.bukalapak.com",
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
                "Accept: application/json",
                "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                "Content-Type: application/json",
                "Origin: https://seller.bukalapak.com",
                "Referer: https://seller.bukalapak.com/",
                "Sec-Fetch-Dest: empty",
                "Sec-Fetch-Mode: cors",
                "Sec-Fetch-Site: same-site",
                "Te: trailers",
            ];

            $data =
                '{"aggregate":{"dibayar":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=non_cancel_requested"},"dibatalkan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=cancel_requested"},"diproses":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=accepted"},"dikirim":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=received&states[]=delivered"},"selesai":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=remitted"},"dikembalikan":{"method":"GET","path":"/transactions?context=sale&limit=1&states[]=refunded"}}}';
            $checkOrder = curl(
                "https://api.bukalapak.com/aggregate?access_token=" .
                    $token .
                    "",
                $data,
                $headers
            );
            $checkOrder = json_decode($checkOrder[1]);
            if ($checkOrder->data->diproses) {
                $idOrder = $checkOrder->data->diproses[$indexLur]->id;
                $idOrderMu =
                    $checkOrder->data->diproses[$indexLur]->transaction_id;
                $productName =
                    $checkOrder->data->diproses[$indexLur]->items[0]->product
                        ->name;
                $quantity =
                    $checkOrder->data->diproses[$indexLur]->items[0]->quantity;
                $price =
                    $checkOrder->data->diproses[$indexLur]->items[0]->product
                        ->price;
                $gameId =
                    $checkOrder->data->diproses[$indexLur]->options->buyer_note;

                if (strpos($productName, "MD")) {
                    echo date("[H:i:s]") .
                        " Order Has Found $productName !!! \n";
                    echo date("[H:i:s]") . " Quantity Item $quantity !!! \n";
                    $target = explode(" ", $gameId);
                    for ($checkId = 0; $checkId < count($target); $checkId++) {
                        $idHiggs = $target[$checkId];
                        $idHiggs = preg_replace("/[^0-9]/", "", $idHiggs);

                        if (strpos($productName, "1M")) {
                            $totalChipPembeli = "1m";
                        } elseif (strpos($productName, "60M")) {
                            $totalChipPembeli = "60m";
                        } elseif (strpos($productName, "200M")) {
                            $totalChipPembeli = "200m";
                        } elseif (strpos($productName, "400M")) {
                            $totalChipPembeli = "400m";
                        } elseif (strpos($productName, "1B")) {
                            $totalChipPembeli = "1b";
                        } elseif (strpos($productName, "2B")) {
                            $totalChipPembeli = "2b";
                        } elseif (strpos($productName, "5B")) {
                            $totalChipPembeli = "5b";
                        } elseif (strpos($productName, "10B")) {
                            $totalChipPembeli = "10b";
                        }

                        if (strlen($idHiggs) > 9) {
                            $idGameKu = "Invalid ID";
                        }

                        if (strlen($idHiggs) < 6) {
                            $idGameKu = "Invalid ID";
                        }

                        if (strlen($idHiggs) == 9) {
                            $idGameKu = $idHiggs;
                            break;
                        }

                        if (strlen($idHiggs) == 8) {
                            $idGameKu = $idHiggs;
                            break;
                        }

                        if (strlen($idHiggs) == 7) {
                            $idGameKu = $idHiggs;
                            break;
                        }

                        if (strlen($idHiggs) == 6) {
                            $idGameKu = $idHiggs;
                            break;
                        }
                    }

                    $headers = [
                        "Host: trade.topbos.com",
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
                        "Accept: application/json, text/javascript, */*; q=0.01",
                        "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                        "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
                        "Origin: https://trade.topbos.com",
                        "Referer: https://trade.topbos.com/",
                        "Sec-Fetch-Dest: empty",
                        "Sec-Fetch-Mode: cors",
                        "Sec-Fetch-Site: same-origin",
                        "Te: trailers",
                        "Connection: close",
                    ];

                    $data =
                        "v=706172746E657249643D353836393736267077643D3061363665376131646533316531306533336139343266316332353731383835";
                    $login = curl(
                        "https://trade.topbos.com/trade/pwdLogin",
                        $data,
                        $headers
                    );
                    $cookie = $login[2];
                    $login = json_decode($login[1]);
                    $info = $login->msg;
                    $aliyungf_tc = $cookie["aliyungf_tc"];
                    $tradeuid = $cookie["trade-cookie-uid"];
                    $tradetoken = $cookie["trade-cookie-token"];

                    if ($info == "201") {
                        echo "\nSuccesfully Login\n\n";

                        $headers = [
                            "Host: trade.topbos.com",
                            "Cookie: aliyungf_tc=" .
                            $aliyungf_tc .
                            "; trade-cookie-uid=" .
                            $tradeuid .
                            "; trade-cookie-token=" .
                            $tradetoken .
                            "; DAY_ONCE_SHOW_24=1",
                            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
                            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                            "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                            "Referer: https://trade.topbos.com/index.html",
                            "Upgrade-Insecure-Requests: 1",
                            "Sec-Fetch-Dest: document",
                            "Sec-Fetch-Mode: navigate",
                            "Sec-Fetch-Site: same-origin",
                            "Sec-Fetch-User: ?1",
                            "Te: trailers",
                            "Connection: close",
                        ];

                        $data = "buyerId=" . $idGameKu . "";
                        $checkName = curl(
                            "https://trade.topbos.com/trade/queryBuyer",
                            $data,
                            $headers
                        );
                        $checkName = json_decode($checkName[1]);
                        $name = $checkName->msg;

                        if ($name) {
                            echo "\e[0;0m Nick Target    : \e[0;32m$name\e[0m\n\n";
                        }

                        $index = curlget(
                            "https://trade.topbos.com/trade/index?projectId=0",
                            null,
                            $headers
                        );
                        $data = get_between_array(
                            $index[1],
                            '<p class="rechargeTitle">',
                            "</p>"
                        );
                        $stock = get_between_array(
                            $index[1],
                            '<p class="itemPrice">',
                            "</p>"
                        );
                        $idItem = get_between_array(
                            $index[1],
                            '<li id="itemId_',
                            '"'
                        );
                        $total = count($data);

                        $terkirim = "Chip Belum Terkirim";
                        for ($i = 0; $i < $total; $i++) {
                            $length = strlen($idItem[$i]);
                            $lengthData = strlen($data[$i]);
                            $totalChip = preg_split("/[s ]+/", $data[$i]);
                            $totalChipBot = $totalChip[3];
                            $totalChipBot = strtolower($totalChipBot);

                            if ($lengthData == 1) {
                                break;
                            }

                            if ($length == 1) {
                                echo "\e[0;0m [$i] Name Item      : \e[0;32m$data[$i]\e[0m\n";
                                echo "\e[0;0m     Stock Item     : \e[0;32m$stock[$i]\e[0m\n";
                                echo "\e[0;0m     ID Item        : \e[0;32m$idItem[$i]\e[0m\n";
                                echo "\e[0;0m     Total Chip     : \e[0;32m$totalChipBot\e[0m\n\n";
                            } else {
                                echo "\e[0;31m Error Contact Admin\e[0m\n";
                            }
                        }

						for ($i=0; $i < $quantity; $i++) { 
							if ($totalChipPembeli == "1m") {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1m\n";
									$data =
										"itemId=6&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 1m\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
							}

							if ($totalChipPembeli == "30m") {
								for ($index = 0; $index < 30; $index++) {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1m x 30\n";
									$data =
										"itemId=6&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 30m\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
								}
							}

							if ($totalChipPembeli == "60m") {
									echo "\e[0;0m     On Progress Send Voucher koin emas 60m\n";
									$data =
										"itemId=1&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 60m\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
							}

							if ($totalChipPembeli == "200m") {
								echo "\e[0;0m     On Progress Send Voucher koin emas 200m\n";
								$data =
									"itemId=2&buyerId=" .
									$idGameKu .
									"";
								$sendCoin = curl(
									"https://trade.topbos.com/trade/sellCard",
									$data,
									$headers
								);
								$sendCoin = json_decode($sendCoin[1]);
								$msg = $sendCoin->msg;

								if ($msg == '"success"') {
									echo "\e[0;0m     Successfully Send Voucher koin emas 200m\n";
									$terkirim = "Chip Telah Terkirim";

									continue;
								} else {
									echo "\e[0;0m     Information    : $msg\n";
									$terkirim =
										"Chip Belum Terkirim Bro";
									continue;
								}
							}

							if ($totalChipPembeli == "400m") {
								echo "\e[0;0m     On Progress Send Voucher koin emas 400m\n";
								$data =
									"itemId=3&buyerId=" .
									$idGameKu .
									"";
								$sendCoin = curl(
									"https://trade.topbos.com/trade/sellCard",
									$data,
									$headers
								);
								$sendCoin = json_decode($sendCoin[1]);
								$msg = $sendCoin->msg;

								if ($msg == '"success"') {
									echo "\e[0;0m     Successfully Send Voucher koin emas 400m\n";
									$terkirim = "Chip Telah Terkirim";

									continue;
								} else {
									echo "\e[0;0m     Information    : $msg\n";
									$terkirim =
										"Chip Belum Terkirim Bro";
									continue;
								}
							}

							if ($totalChipPembeli == "1b") {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1B\n";
									$data =
										"itemId=5&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;
									$msg = '"success"';
									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 1B\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";

										continue;
									}
							}

							if ($totalChipPembeli == "2b") {
								for ($index = 0; $index < 2; $index++) {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1B x 2\n";
									$data =
										"itemId=5&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 2B\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";

										continue;
									}
								}
							}

							if ($totalChipPembeli == "4b") {
								for ($index = 0; $index < 4; $index++) {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1B x 4\n";
									$data =
										"itemId=5&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 4B\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
								}
							}

							if ($totalChipPembeli == "5b") {
								for ($index = 0; $index < 5; $index++) {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1B x 5\n";
									$data =
									    "itemId=5&buyerId=" .
									    $idGameKu .
									    "";
									$sendCoin = curl(
									    "https://trade.topbos.com/trade/sellCard",
									    $data,
									    $headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;
									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 5B\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
								}
							}

							if ($totalChipPembeli == "10b") {
								for ($index = 0; $index < 10; $index++) {
									echo "\e[0;0m     On Progress Send Voucher koin emas 1B x 10\n";
									$data =
										"itemId=5&buyerId=" .
										$idGameKu .
										"";
									$sendCoin = curl(
										"https://trade.topbos.com/trade/sellCard",
										$data,
										$headers
									);
									$sendCoin = json_decode($sendCoin[1]);
									$msg = $sendCoin->msg;

									if ($msg == '"success"') {
										echo "\e[0;0m     Successfully Send Voucher koin emas 10B\n";
										$terkirim = "Chip Telah Terkirim";

										continue;
									} else {
										echo "\e[0;0m     Information    : $msg\n";
										$terkirim =
											"Chip Belum Terkirim Bro";
										continue;
									}
								}
							}
						}
                    }

                    $table->row([
                        "No Order" => $idOrder,
                        // 'ID Higgs'   => $idGameKu,
                        "Name Product" => $productName,
                        "Qty" => $quantity,
                        "Price" => $price,
                        "Status Kirim" => $terkirim,
                    ]);

                    $list = [
                        [
                            "$idOrder",
                            "$idGameKu",
                            "$productName",
                            "$quantity",
                            "$price",
                            "$terkirim",
                            date("[H:i:s]"),
                        ],
                    ];

                    $fp = fopen("$time.csv", "a+");

                    foreach ($list as $date) {
                        fputcsv($fp, $date);
                    }

                    $headers = [
                        "Host: api.bukalapak.com",
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
                        "Accept: application/json",
                        "Accept-Language: id,en-US;q=0.7,en;q=0.3",
                        "Content-Type: application/json",
                        "Origin: https://seller.bukalapak.com",
                        "Referer: https://seller.bukalapak.com/",
                        "Sec-Fetch-Dest: empty",
                        "Sec-Fetch-Mode: cors",
                        "Sec-Fetch-Site: same-site",
                        "Te: trailers",
                    ];

                    $data =
                        '{"state":"delivered","state_options":{"tracking_number":"DG1lrc'.$randAngka.'","carrier":"Kurir Lapak","manual_switch":false,"manual_switch_voucher":false}}';
                    $approve = curlPut(
                        "https://api.bukalapak.com/transactions/" .
                            $idOrder .
                            "/status?access_token=" .
                            $token .
                            "",
                        $data,
                        $headers
                    );
                    $approve = json_decode($approve[1]);

                    $headers = [
                        'Host: api.bukalapak.com',
                        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0',
                        'Accept: application/json',
                        'Accept-Language: id,en-US;q=0.7,en;q=0.3',
                        'Content-Type: application/json;charset=utf-8',
                        'Origin: https://seller.bukalapak.com',
                        'Referer: https://seller.bukalapak.com/',
                        'Sec-Fetch-Dest: empty',
                        'Sec-Fetch-Mode: cors',
                        'Sec-Fetch-Site: same-site',
                        'If-None-Match: W/"0b472d98c55b8877bbbbd1b3b028e08e"',
                        'Te: trailers',
                    ];

                    $sendMessage2 = curlget('https://api.bukalapak.com/transactions/'.$idOrder.'?access_token='.$token.'', null, $headers);
                    $sendMessage = json_decode($sendMessage2[1]);
                    $invId = $sendMessage->data->invoice_id;
                    $partnerId = $sendMessage->data->buyer->id;

                    $headers = [
                        'Host: api.bukalapak.com',
                        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0',
                        'Accept: application/json, text/plain, */*',
                        'Accept-Language: id,en-US;q=0.7,en;q=0.3',
                        'Content-Type: application/json;charset=utf-8',
                        'Origin: https://seller.bukalapak.com',
                        'Referer: https://seller.bukalapak.com/',
                        'Sec-Fetch-Dest: empty',
                        'Sec-Fetch-Mode: cors',
                        'Sec-Fetch-Site: same-site',
                        'Te: trailers',
                    ];


                    $data = '{"content":"Cek inbox karena toko ini menggunakan fitur kirim otomatis jadi pastikan id benar , silakan lakukan konfirmasi terima barang untuk transaksi '.$idOrderMu.' jika pesananmu sudah kamu terima dan jangan lupa klik link https://www.bukalapak.com/u/hasnah_772325","types":[{"id":"'.$idOrder.'","invoice_id":"'.$invId.'","transaction_id":"'.$idOrderMu.'","type":"transaction"}],"partner_id":"'.$partnerId.'"}';
                    $sendChat = curl('https://api.bukalapak.com/chat/messages?access_token='.$token.'', $data, $headers);
                    echo "\e[0;0m     Information    : Successfully Send Message\n";


                    $no++;
                }
            }
        }
    } else {
        echo date("[H:i:s]") . " Waiting For Order !!!\n";
    }
}

function get()
{
    return trim(fgets(STDIN));
}

function get_between($string, $start, $end)
{
    $string = " " . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) {
        return "";
    }
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_between_array($string, $start, $end)
{
    $aa = explode($start, $string);
    for ($i = 0; $i < count($aa); $i++) {
        $su = explode($end, $aa[$i]);
        $uu[] = $su[0];
    }
    unset($uu[0]);
    $uu = array_values($uu);
    return $uu;
}
function nama()
{
    $ch = curl_init();
    curl_setopt(
        $ch,
        CURLOPT_URL,
        "http://ninjaname.horseridersupply.com/indonesian_name.php"
    );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    $ex = curl_exec($ch);
    // $rand = json_decode($rnd_get, true);
    preg_match_all("~(&bull; (.*?)<br/>&bull; )~", $ex, $name);
    return $name[2][mt_rand(0, 14)];
}
function acak($panjang)
{
    $karakter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $string = "";
    for ($i = 0; $i < $panjang; $i++) {
        $pos = rand(0, strlen($karakter) - 1);
        $string .= $karakter[$pos];
    }
    return $string;
}

function acakc($panjang)
{
    $karakter = "abcdefghijklmnopqrstuvwxyz1234567890";
    $string = "";
    for ($i = 0; $i < $panjang; $i++) {
        $pos = rand(0, strlen($karakter) - 1);
        $string .= $karakter[$pos];
    }
    return $string;
}
function angka($panjang)
{
    $karakter = "1234567890";
    $string = "";
    for ($i = 0; $i < $panjang; $i++) {
        $pos = rand(0, strlen($karakter) - 1);
        $string .= $karakter[$pos];
    }
    return $string;
}
// function curl($url,$post,$headers, $socks)
// {
// 	$ch = curl_init();
// 	curl_setopt($ch, CURLOPT_URL, $url);
// 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// 	curl_setopt($ch, CURLOPT_HEADER, 1);
// 	if ($headers !== null) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//     if ($post !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
//     if ($socks):
//         curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
//         curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
//         curl_setopt($ch, CURLOPT_PROXY, $socks);
//       endif;
// 	$result = curl_exec($ch);
// 	$header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
// 	$body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
// 	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $result, $matches);
// 	$cookies = array()
// ;	foreach($matches[1] as $item) {
// 	  parse_str($item, $cookie);
// 	  $cookies = array_merge($cookies, $cookie);
// 	}
// 	return array (
// 	$header,
// 	$body,
// 	$cookies
// 	);
// }

function curl($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    if ($post !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

function curltor($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_PROXY, "http://127.0.0.1:9150/");
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    if ($post !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

function curlget($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $headers == null
        ? curl_setopt($ch, CURLOPT_POST, 1)
        : curl_setopt($ch, CURLOPT_HTTPGET, 1);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

function curlgettor($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $headers == null
        ? curl_setopt($ch, CURLOPT_POST, 1)
        : curl_setopt($ch, CURLOPT_HTTPGET, 1);
    curl_setopt($ch, CURLOPT_PROXY, "http://127.0.0.1:9150/");
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

function curlPut($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $headers == null
        ? curl_setopt($ch, CURLOPT_POST, 1)
        : curl_setopt($ch, CURLOPT_HTTPGET, 1);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

function curlPuttor($url, $post, $headers)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $headers == null
        ? curl_setopt($ch, CURLOPT_POST, 1)
        : curl_setopt($ch, CURLOPT_HTTPGET, 1);
    curl_setopt($ch, CURLOPT_PROXY, "http://127.0.0.1:9150/");
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    if ($headers !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    $result = curl_exec($ch);
    $header = substr($result, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $body = substr($result, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    preg_match_all("/^Set-Cookie:\s*([^;]*)/mi", $result, $matches);
    $cookies = [];
    foreach ($matches[1] as $item) {
        parse_str($item, $cookie);
        $cookies = array_merge($cookies, $cookie);
    }
    return [$header, $body, $cookies];
}

class Colors
{
    private $foreground_colors = [];
    private $background_colors = [];

    public function __construct()
    {
        // Set up shell colors
        $this->foreground_colors["black"] = "0;30";
        $this->foreground_colors["dark_gray"] = "1;30";
        $this->foreground_colors["blue"] = "0;34";
        $this->foreground_colors["light_blue"] = "1;34";
        $this->foreground_colors["green"] = "0;32";
        $this->foreground_colors["light_green"] = "1;32";
        $this->foreground_colors["cyan"] = "0;36";
        $this->foreground_colors["light_cyan"] = "1;36";
        $this->foreground_colors["red"] = "0;31";
        $this->foreground_colors["light_red"] = "1;31";
        $this->foreground_colors["purple"] = "0;35";
        $this->foreground_colors["light_purple"] = "1;35";
        $this->foreground_colors["brown"] = "0;33";
        $this->foreground_colors["yellow"] = "1;33";
        $this->foreground_colors["light_gray"] = "0;37";
        $this->foreground_colors["white"] = "1;37";

        $this->background_colors["black"] = "40";
        $this->background_colors["red"] = "41";
        $this->background_colors["green"] = "42";
        $this->background_colors["yellow"] = "43";
        $this->background_colors["blue"] = "44";
        $this->background_colors["magenta"] = "45";
        $this->background_colors["cyan"] = "46";
        $this->background_colors["light_gray"] = "47";
    }

    // Returns colored string
    public function getColoredString(
        $string,
        $foreground_color = null,
        $background_color = null
    ) {
        $colored_string = "";

        // Check if given foreground color found
        if (isset($this->foreground_colors[$foreground_color])) {
            $colored_string .=
                "\033[" . $this->foreground_colors[$foreground_color] . "m";
        }
        // Check if given background color found
        if (isset($this->background_colors[$background_color])) {
            $colored_string .=
                "\033[" . $this->background_colors[$background_color] . "m";
        }

        // Add string and end coloring
        $colored_string .= $string . "\033[0m";

        return $colored_string;
    }

    // Returns all foreground color names
    public function getForegroundColors()
    {
        return array_keys($this->foreground_colors);
    }

    // Returns all background color names
    public function getBackgroundColors()
    {
        return array_keys($this->background_colors);
    }
}

function multicurl($arrayreq)
{
    $mh = curl_multi_init();
    $curl_array = [];
    for ($i = 0; $i < count($arrayreq); $i++) {
        $curl_array[$i] = curl_init();
        curl_setopt($curl_array[$i], CURLOPT_URL, $arrayreq[$i][0]);
        curl_setopt($curl_array[$i], CURLOPT_RETURNTRANSFER, true);
        if ($arrayreq[$i][1] != null) {
            curl_setopt($curl_array[$i], CURLOPT_POSTFIELDS, $arrayreq[$i][1]);
        }
        curl_setopt($curl_array[$i], CURLOPT_CUSTOMREQUEST, $arrayreq[$i][2]);
        if ($arrayreq[$i][3] != null) {
            curl_setopt($curl_array[$i], CURLOPT_HTTPHEADER, $arrayreq[$i][3]);
        }

        curl_setopt($curl_array[$i], CURLOPT_HEADER, true);
        curl_setopt($curl_array[$i], CURLOPT_HEADER, true);
        curl_setopt($curl_array[$i], CURLOPT_ENCODING, "gzip");
        curl_multi_add_handle($mh, $curl_array[$i]);
    }
    $running = null;
    do {
        curl_multi_exec($mh, $running);
    } while ($running > 0);
    for ($i = 0; $i < count($arrayreq); $i++) {
        $header_size = curl_getinfo($curl_array[$i], CURLINFO_HEADER_SIZE);
        $body[] = substr(curl_multi_getcontent($curl_array[$i]), $header_size);
    }
    for ($i = 0; $i < count($arrayreq); $i++) {
        curl_multi_remove_handle($mh, $curl_array[$i]);
    }
    return $body;
}
function request(
    $url,
    $param,
    $headers = null,
    $request = "POST",
    $cookie = null,
    $followlocation = 0,
    $proxy = null,
    $port = null
) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($param != null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
    }
    if ($headers != null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    if ($port != null) {
        curl_setopt($ch, CURLOPT_PORT, $port);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    } elseif ($port == null) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    }
    if ($cookie != null) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    }
    if ($proxy != null) {
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
    }
    if ($followlocation == 1) {
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 100);
    }
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $execute = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($execute, 0, $header_size);
    $body = substr($execute, $header_size);
    curl_close($ch);
    return [$header, $body];
}
